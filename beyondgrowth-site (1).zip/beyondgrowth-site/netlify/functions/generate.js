// Serverless function — generates WhatsApp campaign messages with Claude.
// Your API key lives ONLY here (as a Netlify environment variable), never in the page.
exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: cors, body: '' };
  if (event.httpMethod !== 'POST')  return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server missing ANTHROPIC_API_KEY — add it in Netlify → Site configuration → Environment variables.' }) };

  let brief = '';
  try { brief = String(JSON.parse(event.body || '{}').brief || '').slice(0, 500); } catch (e) {}
  if (!brief.trim()) return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Tell me the business and offer first.' }) };

  const prompt =
`You are a WhatsApp marketing copywriter for Indian local businesses.
Write 3 short WhatsApp campaign messages for this brief:
"${brief}"

Rules:
- Each message MUST include the literal placeholder {name} near the start (it personalises per customer).
- Keep each under 280 characters.
- Warm, friendly, India-appropriate tone. At most 1-2 emojis.
- Include a clear call to action (e.g. reply YES, book now, visit us).
- Make the 3 distinct in angle: one urgency, one value, one friendly invite.

Respond with ONLY a JSON array of 3 strings. No markdown, no preamble.`;

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await r.json();
    if (!r.ok) return { statusCode: 502, headers: cors, body: JSON.stringify({ error: (data.error && data.error.message) || 'AI request failed.' }) };

    let text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('').trim();
    text = text.replace(/^```json/i, '').replace(/^```/, '').replace(/```$/, '').trim();
    let messages;
    try { messages = JSON.parse(text); } catch (e) { messages = [text]; }
    if (!Array.isArray(messages)) messages = [String(messages)];
    messages = messages.filter(Boolean).slice(0, 3);

    return { statusCode: 200, headers: cors, body: JSON.stringify({ messages }) };
  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server error: ' + e.message }) };
  }
};
