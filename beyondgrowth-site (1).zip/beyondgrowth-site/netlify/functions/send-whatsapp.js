// ─────────────────────────────────────────────────────────────────────────
//  send-whatsapp  —  TRUE automated send via the WhatsApp Cloud API (Meta).
//
//  This is the OPTIONAL upgrade from the "tap-to-open-each-chat" flow.
//  It lets the campaign tool send messages itself, with no manual tapping.
//
//  It only works once you have set BOTH of these in Netlify
//  (Site configuration → Environment variables):
//     WHATSAPP_TOKEN     — the permanent access token from Meta
//     WHATSAPP_PHONE_ID  — the Phone Number ID from your WhatsApp Business app
//
//  Important Meta rules (not optional — they protect your number from a ban):
//   • To message a person who has NOT messaged you in the last 24h you MUST
//     send an APPROVED message TEMPLATE, not free text. Pass the template name
//     in `template` and Meta fills {name} etc. from `variables`.
//   • Free text (`message`) only reaches people inside the 24-hour window.
//   • Recipients must have opted in. Don't blast cold numbers.
// ─────────────────────────────────────────────────────────────────────────
exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: cors, body: '' };
  if (event.httpMethod !== 'POST')  return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };

  const token   = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  if (!token || !phoneId) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({
      error: 'Automated sending is not set up yet. Add WHATSAPP_TOKEN and WHATSAPP_PHONE_ID in Netlify → Environment variables (see SETUP.md, step 4).'
    }) };
  }

  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch (e) {}

  const to = String(body.to || '').replace(/\D/g, '');     // digits only, with country code
  if (to.length < 8) return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'A valid number (with country code) is required.' }) };

  // Build the Cloud API payload — template (preferred) or plain text.
  let payload;
  if (body.template) {
    // variables is an array of strings that fill {{1}}, {{2}}, ... in the template body
    const vars = Array.isArray(body.variables) ? body.variables : [];
    payload = {
      messaging_product: 'whatsapp',
      to,
      type: 'template',
      template: {
        name: String(body.template),
        language: { code: body.lang || 'en' },
        components: vars.length ? [{
          type: 'body',
          parameters: vars.map(v => ({ type: 'text', text: String(v) }))
        }] : []
      }
    };
  } else {
    const text = String(body.message || '').slice(0, 1000);
    if (!text.trim()) return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Nothing to send — provide message or template.' }) };
    payload = {
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body: text }
    };
  }

  try {
    const r = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    if (!r.ok) {
      const msg = (data.error && data.error.message) || 'WhatsApp send failed.';
      return { statusCode: 502, headers: cors, body: JSON.stringify({ error: msg, detail: data.error || null }) };
    }
    const id = data.messages && data.messages[0] && data.messages[0].id;
    return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, id }) };
  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server error: ' + e.message }) };
  }
};
