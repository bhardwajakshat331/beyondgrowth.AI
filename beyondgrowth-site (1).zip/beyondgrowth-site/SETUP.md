# Beyondgrowth AI — make it fully functional

This folder is the complete, deploy-ready site. Everything is already wired:

| Piece | What it does | Status |
|---|---|---|
| `index.html` | Public site + gated WhatsApp campaign tool + AI message writer | ✅ wired |
| `admin.html` | Private dashboard to read/update leads & queries | ✅ wired |
| `netlify/functions/generate.js` | AI writes 3 WhatsApp messages (uses Claude, key stays server-side) | ✅ wired |
| `netlify/functions/send-whatsapp.js` | **Optional** true automated send via WhatsApp Cloud API | ✅ ready, off by default |
| `netlify.toml` | Tells Netlify where the functions live | ✅ |
| `supabase-setup.sql` | Creates your two database tables + security rules | ✅ run once |

You only need to do the steps below once. The site works after **Step 2**; Steps 3–4 add the database and true automation.

---

## Step 1 — Put the code on Netlify
1. Go to netlify.com → **Add new site → Deploy manually**.
2. Drag this whole `beyondgrowth-site` folder onto the drop zone.
3. You get a live URL (e.g. `beyondgrowth.netlify.app`). Add your custom domain later under **Domain settings**.

At this point the site is live. The contact + application forms already email you (see note on FormSubmit below). The AI writer needs Step 2.

## Step 2 — Turn on the AI message writer
1. Get an API key at console.anthropic.com → **API keys**.
2. Netlify → your site → **Site configuration → Environment variables → Add**:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your key (`sk-ant-…`)
3. **Trigger deploy → Deploy site** so the function picks up the key.
4. On the site, unlock the tool, type a brief like *"Café in Gurgaon — 20% off weekend brunch"*, tap **Write 3 messages**. Tap one to drop it into the offer box.

> The key lives only in the serverless function, never in the page — safe to share the site publicly.

## Step 3 — Turn on the database + admin dashboard
1. supabase.com → **New project**. When it's ready, open **SQL Editor → New query**.
2. Paste the entire contents of `supabase-setup.sql` and click **Run**. (Creates `applications` + `queries`, public can only submit, only you can read.)
3. Supabase → **Project Settings → API**. Copy the **Project URL** and the **anon public** key.
4. Paste BOTH values into the CONFIG block near the top of **`index.html`** *and* the matching block in **`admin.html`** (same two values in both files):
   ```js
   const SB_URL  = "https://YOUR-PROJECT-ID.supabase.co";
   const SB_ANON = "YOUR-ANON-PUBLIC-KEY";
   ```
5. Create your admin login: Supabase → **Authentication → Users → Add user** (email + password). That's what you'll log into `admin.html` with.
6. Re-deploy (drag the folder again). Visit `your-site.netlify.app/admin.html`, sign in — every application and query now appears, searchable, with status tracking and CSV export.

> Until you do Step 3 the site still works fine — leads just arrive by email and in the on-page leads viewer instead of the database.

## Step 4 — (Optional) True automated WhatsApp sending
Right now the campaign tool opens each chat pre-filled and you tap **Send** — compliant and zero-setup. To make it send every message **itself**:

1. Set up **WhatsApp Cloud API** in Meta (business.facebook.com → WhatsApp → API setup). You'll get a **Phone Number ID** and a permanent **access token**.
2. Netlify → Environment variables → add:
   - `WHATSAPP_TOKEN` = your permanent token
   - `WHATSAPP_PHONE_ID` = your phone number ID
3. In `index.html` CONFIG, set `waAutoSend: true`. Re-deploy.
4. Build a campaign — a **"Send all automatically →"** button now appears and sends through the Cloud API.

**Meta's rules (these protect your number from being banned):**
- To message someone who hasn't messaged *you* in the last 24 hours, you must use an **approved message template**, not free text. Create one in Meta, then put its name in `waTemplate` in CONFIG — `{name}` is passed in automatically as the first variable.
- Free text only reaches people inside the 24-hour window.
- Only message people who opted in. Don't import cold lists.

---

### Notes
- **FormSubmit activation:** the *first* time any form is submitted, FormSubmit emails `bhardwajakshat331@gmail.com` a one-time "Activate" link. Click it once; after that every application/query lands in your inbox.
- **Changing your details:** WhatsApp number, email, and Instagram are in the `CONFIG` block in `index.html`.
- **Local preview:** functions only run on Netlify (or `netlify dev`). Opening `index.html` directly works for everything except the AI writer and auto-send.
