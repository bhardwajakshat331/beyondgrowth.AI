-- ════════════════════════════════════════════════════════════════════════
--  Beyondgrowth AI — database setup
--  Run this ONCE in Supabase → your project → SQL Editor → New query → Run.
--  It creates two tables and locks them down so the public can submit forms
--  but ONLY your logged-in admin can read the leads.
-- ════════════════════════════════════════════════════════════════════════

-- 1) Applications (from the "Select plan" form)
create table if not exists applications (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz not null default now(),
  ref         text,
  name        text,
  business    text,
  whatsapp    text,
  email       text,
  plan        text,
  price       text,
  billing     text,
  status      text not null default 'new'
);

-- 2) Queries (from the "Ask a question" form)
create table if not exists queries (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz not null default now(),
  name        text,
  contact     text,
  message     text,
  status      text not null default 'new'
);

-- 3) Turn on Row Level Security (locks both tables by default)
alter table applications enable row level security;
alter table queries      enable row level security;

-- 4) Allow the public website (anon key) to INSERT only — never read
create policy "public can submit applications"
  on applications for insert to anon with check (true);
create policy "public can submit queries"
  on queries for insert to anon with check (true);

-- 5) Allow your logged-in admin to READ and UPDATE everything
create policy "admin reads applications"
  on applications for select to authenticated using (true);
create policy "admin updates applications"
  on applications for update to authenticated using (true);
create policy "admin reads queries"
  on queries for select to authenticated using (true);
create policy "admin updates queries"
  on queries for update to authenticated using (true);
